<?php

namespace App\Http\Controllers\api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\JscodeSession;
use App\JsCode;
use Response;
class JscodeSessionController extends Controller
{
   public function __construct()
   {
	   
   }
   public function set_session(Request $request)
   {
	   $jscode=new JsCode;
	   $check=JsCode::where('code',$request->js_code)->first();
	   if($check)
	   {
	   $JscodeSession=new JscodeSession;
	   $JscodeSession->appid=$request->appid;
	   $JscodeSession->secret=$request->secret;
	   $JscodeSession->js_code=$check->id;
	   $JscodeSession->grant_type=$request->grant_type;
	   $openid=$this->generateRandomString(8);
	   $session_key=$this->generateRandomString(20);
	   $unionid=$this->generateRandomString(10);
	   $JscodeSession->openid=$openid;
	   $JscodeSession->session_key=$session_key;
	   $JscodeSession->unionid=$unionid;
	   $JscodeSession->save();
	   return response()->json(['openid' => $openid,'session_key'=>$session_key,'unionid'=>$unionid]);
	   }
	   else
		   return response()->json(['errcode' => '40029','errmsg'=>'invalid code']);
   }
   
   function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
}

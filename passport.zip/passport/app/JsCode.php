<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JsCode extends Model
{
	public $timestamps = true;
    protected $table = 'js_code';
  protected $fillable = ['code'];

  




}

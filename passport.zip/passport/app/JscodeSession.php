<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JscodeSession extends Model
{
	public $timestamps = true;
    protected $table = 'jscode_session';
  protected $fillable = ['appid', 'secret', 'js_code', 'grant_type', 'session_key','openid','unionid'];

  




}

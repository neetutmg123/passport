<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::group(['namespace' => 'api'], function () {
    Route::post('/login', 'UserController@login');
    Route::post('/jscode2session', 'JscodeSessionController@set_session');
	
	//Route::middleware('auth:api')->post('/auth/token', 'OauthController@authenticate');
});
Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('oauth/token', [
    'middleware' => 'password-grant',
    'uses' => '\laravel\passport\src\Http\Controllers\AccessTokenController@issueToken'
]);
Route::post('oauth/token/refresh', [
    'middleware' => ['web', 'auth', 'password-grant'],
    'uses' => '\Laravel\Passport\Http\Controllers\TransientTokenController@refresh'
]);

Route::get('oauth/access_token', function() {
// return Response::json(Authorizer::issueAccessToken());
$guzzle = new GuzzleHttp\Client;

$response = $guzzle->post('http://localhost/passport/public/api/oauth/token', [
    'form_params' => [
        'grant_type' => 'client_credentials',
        'client_id' => 'client-id',
        'client_secret' => 'client-secret',
        'scope' => 'your-scope',
    ],
]);
return Response::json(['message'=>'success', 'data'=>$response->getBody()]);
//return json_decode((string) $response->getBody(), true)['access_token'];
});

Route::get('/redirect', function () {
    $query = http_build_query([
        'client_id' => 'client-id',
        'redirect_uri' => 'http://example.com/callback',
        'response_type' => 'code',
        'scope' => '',
    ]);
return Response::json(['message'=>'success', 'data'=>$query]);
   // return redirect('http://your-app.com/oauth/authorize?'.$query);
});

